function [name, ufid, ...
    transform_A1, transform_A2, transform_A3, ...
    transform_B1, transform_B2, transform_B3, ...
    C1, C2, C3, transform_C1, transform_C2, transform_C3, ...
    example_neither, transform_neither] = Exercise2(A1, A2, A3, B1, B2, B3)
    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;

    % --- Part A (see transformation.m) [10 Points] --- %

    % --- Part B [10 Points] --- %
    transform_A1 = NaN;
    transform_A2 = NaN;
    transform_A3 = NaN;

    transform_B1 = NaN;
    transform_B2 = NaN;
    transform_B3 = NaN;

    C1 = NaN;
    C2 = NaN;
    C3 = NaN;

    transform_C1 = NaN;
    transform_C2 = NaN;
    transform_C3 = NaN;

    % --- Part C [10 Points] --- %

    %{ 
    (1) When m < n, a transformation T(x) = Ax cannot be one-to-one because
        (EXPLAIN USING MATHEMATICAL REASONING)
     
    (2) When m > n, a transformation T(x) = Ax cannot be onto because
        (EXPLAIN USING MATHEMATICAL REASONING)
     
    (3) When m = n, a transformation T(x) = Ax 
        (EXPLAIN USING MATHEMATICAL REASONING OR GIVE A NONTRIVIAL EXAMPLE BELOW)
    
    %}

    example_neither = NaN;
    transform_neither = NaN;

    %{ 
    (4) When m = n, a transformation T(x) = Ax 
       (EXPLAIN USING MATHEMATICAL REASONING)

    %}
end

