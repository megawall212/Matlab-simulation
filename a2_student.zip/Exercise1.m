function [name, ufid, ...
    A1, A2, A3, dep_A1, dep_A2, dep_A3, ...
    B1, B2, B3, dep_B1, dep_B2, dep_B3, ...
    example_B, dep_B, example_C, dep_C] = Exercise1()
    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;

    % --- Part A [10 Points] --- %
    % (1) m < n
    A1 = NaN;
    A2 = NaN;
    A3 = NaN;

    dep_A1 = NaN;
    dep_A2 = NaN;
    dep_A3 = NaN;

    % (2) m > n
    B1 = NaN;
    B2 = NaN;
    B3 = NaN;

    dep_B1 = NaN;
    dep_B2 = NaN;
    dep_B3 = NaN;

    % --- Part B [10 Points] --- %
    %{ 
    (OBSERVE & EXPLAIN)
    %}

    example_B = NaN;
    dep_B = NaN;

    % --- Part C [10 Points] --- %
    %{ 
    (OBSERVE & EXPLAIN)
    %}

    example_C = NaN;
    dep_C = NaN;
end
