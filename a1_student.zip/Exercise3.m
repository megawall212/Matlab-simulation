function [name, ufid, ...
          bA, A1, Ab1, sol1, A2, Ab2, sol2, A3, Ab3, sol3, ...
          example_A1, example_b1, example_type1, ...
          bC, A4, Ab4, sol4, A5, Ab5, sol5, A6, Ab6, sol6, ...
          example_A2, example_b2, example_type2, ...
          example_A3, example_b3, example_type3] = Exercise3()
    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;

    % --- Part A: Underdetermined Systems [10 Points] --- %
    bA = NaN;
    
    A1 = NaN;
    Ab1 = NaN;
    %[~, n] = NaN; % (UNCOMMENT LINE)
    sol1 = NaN;

    A2 = NaN;
    Ab2 = NaN;
    %[~, n] = NaN; % (UNCOMMENT LINE)
    sol2 = NaN;

    A3 = NaN;
    Ab3 = NaN;
    %[~, n] = NaN; % (UNCOMMENT LINE)
    sol3 = NaN;
    
    % --- Part B: Explanation of Part A [10 Points] --- %

    %{ 
    (EXPLAIN)
    %}

    % (LEAVE THE FOLLOWING AS NaN OR PROVIDE AN EXAMPLE IF POSSIBLE)
    % (WHEN PROVIDING AN EXAMPLE, IT MUST BE A NON-TRIVIAL EXAMPLE.)
    % (i.e., A MATRIX DOES NOT CONTAIN A ZERO ROW AND DOES NOT HAVE TWO OR MORE IDENTICAL ROWS.)
    example_A1 = NaN;
    example_b1 = NaN;
    example_type1 = NaN; % (REMOVE LINE IF EXAMPLE)
    %[~, n] = size(example_A1); % (UNCOMMENT IF EXAMPLE)
    %example_type1 = LS_solution(n, example_A1, [example_A1, example_b1]); % (UNCOMMENT IF EXAMPLE)
   
    % --- Part C: Overdetermined Systems [10 Points] --- %
    bC = NaN;

    A4 = NaN;
    Ab4 = NaN;
    %[~, n] = NaN; % (UNCOMMENT LINE)
    sol4 = NaN;

    A5 = NaN;
    Ab5 = NaN;
    %[~, n] = NaN; % (UNCOMMENT LINE)
    sol5 = NaN;

    A6 = NaN;
    Ab6 = NaN;
    %[~, n] = NaN; % (UNCOMMENT LINE)
    sol6 = NaN;
    
    % --- Part D: Explanation of Part C [10 Points] --- %
    
    %{ 
    (EXPLAIN)
    %}

    % (PROVIDE AN EXAMPLE WITH ONE SOLUTION BELOW WITH A NONTRIVIAL MATRIX)
    example_A2 = NaN;
    example_b2 = NaN;
    example_type2 = NaN; % (REMOVE LINE)
    %[~, n] = size(example_A2); % (UNCOMMENT)
    %example_type2 = LS_solution(n, example_A2, [example_A2, example_b2]); % (UNCOMMENT)

    % (PROVIDE AN EXAMPLE WITH INFINITELY MANY SOLUTIONS BELOW WITH A NONTRIVIAL MATRIX)
    example_A3 = NaN;
    example_b3 = NaN;
    example_type3 = NaN; % (REMOVE LINE)
    %[~, n] = size(example_A3); % (UNCOMMENT IF EXAMPLE)
    %example_type3 = LS_solution(n, example_A3, [example_A3, example_b3]); % (UNCOMMENT)
end
