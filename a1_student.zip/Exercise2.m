function [name, ufid, B, pivcols, compare, m, n, solution_type] = Exercise2(A, b)
    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;

    % --- Part A [10 Points] --- %
    B = NaN; % (REMOVE THIS LINE)
    pivcols = NaN; % (REMOVE THIS LINE)
    ; % (WRITE COMMAND BEFORE SEMI-COLON)
    %{ 
    (COMMENTS FOR B AND pivcols)
    %}

    %{ 
    (EXPLAIN WHY SYSTEM IS INCONSISTENT)
    %}

    % --- Part B [10 Points] --- %
    compare = NaN;
    %{ 
    (STATE THEOREM)
    %}
    
    %{ 
    (APPLY/USE THEOREM & COMPARE TO RESULT FROM PART A)
    %}
   
    % --- Part C [10 Points] --- %
    m = NaN; % (REMOVE THIS LINE)
    n = NaN; % (REMOVE THIS LINE)
    %[m, n] = ; % (UNCOMMENT LINE AND COMPLETE)
    solution_type = NaN;
end
