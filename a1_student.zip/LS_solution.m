function [system_type, name, ufid] = LS_solution(n, A, Ab)
    % (PURPOSE OF FUNCTION)
    % n = (INPUT ARGUMENT COMMENT)
    % A = (INPUT ARGUMENT COMMENT)
    % Ab = (INPUT ARGUMENT COMMENT)

    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;    

    inc = "Inconsistent";
    con_with_one_sol = "Consistent with One Solution";
    con_with_inf_sols = "Consistent with Infinite Solutions";
     
    % Add your code below

end
