function [name, ufid, ...
    u1, u2, v1, v2, v3, ...
    u1_dot_v1, v1_dot_u1, ...
    norm_u1, u1_dot_u1, norm_v1, v1_dot_v1, ...
    LHS1, RHS1, LHS2, RHS2, LHS3, RHS3, ...
    y1, z1, verify_sum1, verify_orthogonal1, ...
    y2, z2, verify_sum2] = Exercise3()
    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;

    % --- Part A [10 Points] --- %
    u1 = NaN;
    u2 = NaN;

    v1 = NaN;
    v2 = NaN;
    v3 = NaN;

    % (i) u1 ⋅ v1 and v1 ⋅ u1
    u1_dot_v1 = NaN;
    v1_dot_u1 = NaN;
    % Property: The dot product/inner products is/are ________. (FILL IN THE BLANK)

    % (ii) ||u1||, u1 ⋅ u1 and ||v1||, v1 ⋅ v1
    norm_u1 = NaN;
    u1_dot_u1 = NaN;

    norm_v1 = NaN;
    v1_dot_v1 = NaN;

    % Relation Between Inner Product & Norm: (COMPLETE)

    % (iii) Verify Cauchy-Schwarz Inequality (|u ⋅ v| <= ||u|| * ||v||)
    % => u1 & v1
    LHS1 = NaN;
    RHS1 = NaN;
    % Observe: (IS LHS1 <= RHS1?)

    % => u2 & v2
    LHS2 = NaN;
    RHS2 = NaN;
    % Observe: (IS LHS2 <= RHS2?)

    % => u2 & v3
    LHS3 = NaN;
    RHS3 = NaN;
    % Observe: (IS LHS3 <= RHS3?)

    %{ 
    The Cauchy-Schwarz Inequality is an equality when... (COMPLETE)
    %}

    % --- Part B (see proj.m) [10 Points] --- %

    % --- Part C [10 Points] --- %
    % (i) v1 as a linear combination of u1 and u1's orthogonal complement
    y1 = NaN; % (REMOVE THIS LINE)
    z1 = NaN; % (REMOVE THIS LINE)
    %[y1, z1] = ; % (UNCOMMENT THIS LINE)

    verify_sum1 = NaN; % (SHOULD EQUAL v1)
    verify_orthogonal1 = NaN; % (SHOULD RETURN A BOOLEAN EXPRESSION)

    % (ii) v2 as a linear combination of u2 and u2's orthogonal complement
    y2 = NaN; % (REMOVE THIS LINE)
    z2 = NaN; % (REMOVE THIS LINE)
    %[y2, z2] = ; % (UNCOMMENT THIS LINE)

    verify_sum2 = NaN; % (SHOULD EQUAL v2)

    % z2 is the zero vector because... (COMPLETE)
end
