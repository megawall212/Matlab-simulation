function [name, ufid, ...
    n1, B1, A1, ...
    P1, D1, PDP1, ...
    P1_again, D1_again, PDP_again, ...
    P2, D2, PDP2, P3, D3, PDP3, ...
    A2, P4, D4, verify1_LHS, verify1_RHS, verify2, basis_eigenspace, ...
    A3, P5, D5, dot_A3, ...
    A4, P6, D6, x, C] = Exercise1()
    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;

    rng(ufid, 'twister') % (DO NOT REMOVE)

    % --- Part A [10 Points] --- %
    % vvv GENERATES RANDI MATRIX WITH DISTINCT EIGENVALUES vvv %
    n1 = 4;
    A1 = [];
    B1 = [];
    while length(unique(diag(A1))) ~= n1
        B1 = randiFullRank([-7, 7], n1);
        A1 = triu(B1); % Returns the upper-triangular part of A1
    end
    % ^^^ DO NOT MODIFY! ^^^ %

    %{ 
    The eigenvalues of A1 are _, _, _, _ because/as... (COMPLETE)
    %}

    P1 = NaN; % (REMOVE THIS LINE)
    D1 = NaN; % (REMOVE THIS LINE)
    %[P1, D1] = ; % (UNCOMMENT THIS LINE)

    %{ 
    P1 is... (COMPLETE)
    D1 is... (COMPLETE)
    %}

    PDP1 = NaN;

    P1_again = NaN; % (REMOVE THIS LINE)
    D1_again = NaN; % (REMOVE THIS LINE)
    %[P1_again, D1_again] = ; % (UNCOMMENT THIS LINE)
    PDP_again = NaN;

    %{ 
    We can conclude that A1 is / is not (CHOOSE ONE) diagonalizable
    since... (COMPLETE)
    %}

    % (i) First distinct diagonalization: re-order eigenvalues on the diagonal of D
    P2 = P1; % (DO NOT REMOVE)
    D2 = D1; % (DO NOT REMOVE)

    % MODIFY P2 & D2 HERE

    PDP2 = NaN;

    % (ii) Second distinct diagonalization: scale one of the eigenvectors in P
    P3 = P1; % (DO NOT REMOVE)
    D3 = D1; % (DO NOT REMOVE)

    % MODIFY P3 HERE

    PDP3 = NaN;

    % --- Part B [10 Points] --- %
    A2 = NaN;

    P4 = NaN; % (REMOVE THIS LINE)
    D4 = NaN; % (REMOVE THIS LINE)
    %[P4, D4] = ; % (UNCOMMENT THIS LINE)

    verify1_LHS = NaN;
    verify1_RHS = NaN;
    verify2 = NaN;

    %{ 
    Observe: (COMPLETE)
    %}

    basis_eigenspace = NaN;

    %{ 
    A2 is not diagonalizable because...
    (i)  (REASON #1)
    (ii) (REASON #2)
    %}

    % --- Part C [10 Points] --- %
    A3 = NaN;

    P5 = NaN; % (REMOVE THIS LINE)
    D5 = NaN; % (REMOVE THIS LINE)
    %[P5, D5] = ; % (UNCOMMENT THIS LINE)

    dot_A3 = NaN;

    % The eigenvectors of A3 are _______. (FILL IN THE BLANK)

    %{ 
    Solution: x(t) = (COMPLETE)
    %}

    % --- Part D [10 Points] --- %
    A4 = NaN;

    P6 = NaN; % (REMOVE THIS LINE)
    D6 = NaN; % (REMOVE THIS LINE)
    %[P6, D6] = ; % (UNCOMMENT THIS LINE)

    % A4 is diagonalizable because... (COMPLETE)

    x = NaN; % (ENTER x0)
    C = NaN;
    %{ 
    Solution: x(t) = (COMPLETE)
    %}
end
