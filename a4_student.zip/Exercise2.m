function [name, ufid, ...
    A, x0, x1, x2, ...
    sol1, P, D, C1, sol2, ...
    x0_another, sol3, C2, sol4] = Exercise2()
    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;

    % --- Part A [10 Points] --- %
    A = NaN;
    x0 = NaN;

    x1 = NaN;
    x2 = NaN;

    % --- Part B (see SolveDiffEq.m) [10 Points] --- %

    % --- Part C [10 Points] --- %
    % Method 1: Call SolveDiffEq(...)
    sol1 = NaN;

    % Method 2: Diagonalization (of the Transformation Matrix)
    P = NaN; % (REMOVE THIS LINE)
    D = NaN; % (REMOVE THIS LINE)
    %[P, D] = NaN; % (UNCOMMENT THIS LINE)

    C1 = NaN;

    sol2 = NaN;

    %{ 
    Observe: (DO THEY PRODUCE THE SAME RESULT?)
    Conclude: In the long run we expect... (COMPLETE)
    %}

    % --- Part D [10 Points] --- %
    x0_another = NaN;

    % Method 1: Call SolveDiffEq(...)
    sol3 = NaN;

    % Method 2: Diagonalization (of the Transformation Matrix)
    C2 = NaN;

    sol4 = NaN;

    %{ 
    Comparison: (COMPARE RESULTS FROM DIFFERENT x0 VECTORS)
    Theorem: (STATE THEOREM)
    Conclusion: In the long run we expect... (COMPLETE)
    %}
end
