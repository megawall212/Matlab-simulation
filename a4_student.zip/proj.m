function [y_hat, z, name, ufid] = proj(y, u)
    % Purpose: (COMMENT)
    % Input Argument [y]: (COMMENT)
    % Input Argument [u]: (COMMENT)
    % Output Argument [y_hat]: (COMMENT)
    % Output Argument [z]: (COMMENT)

    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;

    % (ENTER CODE HERE)
end
