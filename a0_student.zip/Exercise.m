function [name, ufid, u, v, w, x, A, A_11, A_23, A2, A3, B, B2, B3, ...
          b, aug, rref_Ab1, rref_Ab2, pivcols, compare] = Exercise()
    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;

    % --- Extra Credit [6 Points] --- %
    % * Vectors *
    u = NaN; % (COMMENT) 
    v = NaN; % (COMMENT)
    w = NaN; % (COMMENT)
    x = NaN; % (COMMENT)
    
    % * Matrices *
    % Enter entries manually
    A = NaN; 
    A_11 = NaN; % (COMMENT)
    A_23 = NaN; % (COMMENT)
    A2 = NaN; % (COMMENT)
    A3 = NaN; % (COMMENT)
    
    % Randomly generated matrices
    B = NaN; % (COMMENT)
    B2 = NaN; % (COMMENT)
    B3 = NaN; % (COMMENT)
    
    % * Solving Systems *
    % Solve Ax=b using RREF
    b = [1; 2];
    aug = NaN; % (COMMENT)
    rref_Ab1 = NaN; % (COMMENT)
    rref_Ab2 = NaN; % (REMOVE THIS LINE)
    pivcols = NaN; % (REMOVE THIS LINE)
    % [rref_Ab2, pivcols] = NaN; % (UNCOMMENT LINE) 
    %{
    (COMMENTS)
    %}
    
    % Solve Ax=b by comparing the ranks
    compare = NaN; 
    % (COMMENT)
end
